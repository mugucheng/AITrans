function [IsSignificant,ClusterBasedPermuTestIsSignificant,ShuffleIsSignificant,ShuffleSigClusterSize,RealDecodingResultsSigClusterSize,...
    RealDecodingResultsSigClusterID,IsSigLessThanChance,ClusterBasedPermuTestIsSigLessThanChance,RealDecodingResultsSigLessClusterSize]...
    =TCTClusterBasedPermutationTest(RealDecodingResults...
    ,ShuffleTCTDecodingNullDistribution,TestBinNum,ShuffleDecodingTimes,SingleOrTwoSidesTest)

if nargin==4
    IsSingleOrTwoSidesTest=1;
else
    IsSingleOrTwoSidesTest=SingleOrTwoSidesTest;
end

IsSignificant=zeros(TestBinNum,TestBinNum);
ClusterBasedPermuTestIsSignificant=zeros(TestBinNum,TestBinNum);
IsSigLessThanChance=zeros(TestBinNum,TestBinNum);
ClusterBasedPermuTestIsSigLessThanChance=zeros(TestBinNum,TestBinNum);
ShuffleIsSignificant=zeros(ShuffleDecodingTimes,TestBinNum,TestBinNum);
ShuffleSigClusterSize=zeros(TestBinNum,ShuffleDecodingTimes);
RealDecodingResultsSigClusterSize=cell(TestBinNum,1);
RealDecodingResultsSigClusterID=cell(TestBinNum,1);
RealDecodingResultsSigLessClusterSize=cell(TestBinNum,1);
for iTrainBin=1:TestBinNum
    for iTestBin = 1:TestBinNum
        %% permutation test
        if IsSingleOrTwoSidesTest==1%single side test
            temp95Percentile= prctile(ShuffleTCTDecodingNullDistribution(:,iTrainBin,iTestBin),95);
            ShuffleIsSignificant(ShuffleTCTDecodingNullDistribution(:,iTrainBin,iTestBin)>temp95Percentile,iTrainBin,iTestBin)=1;
            if RealDecodingResults(iTrainBin,iTestBin)>temp95Percentile
                IsSignificant(iTrainBin,iTestBin)=1;
            end
        else%two sides test
            temp95Percentile= prctile(ShuffleTCTDecodingNullDistribution(:,iTrainBin,iTestBin),[97.5 2.5]);
            ShuffleIsSignificant(ShuffleTCTDecodingNullDistribution(:,iTrainBin,iTestBin)>temp95Percentile(1),iTrainBin,iTestBin)=1;
            ShuffleIsSignificant(ShuffleTCTDecodingNullDistribution(:,iTrainBin,iTestBin)<temp95Percentile(2),iTrainBin,iTestBin)=-1;
            if RealDecodingResults(iTrainBin,iTestBin)>temp95Percentile(1)
                IsSignificant(iTrainBin,iTestBin)=1;
            elseif RealDecodingResults(iTrainBin,iTestBin)<temp95Percentile(2)
                IsSigLessThanChance(iTrainBin,iTestBin)=-1;
            end            
        end
        %temp=find(ShuffleTCTDecodingNullDistribution(:,iTrainBin,iTestBin)>temp95Percentile);
    end
    %% Calculate the maximum summed cluster size��>95th�� for real decoding results with specific training point
    [tempRealDecodingResultsSigClusterSize,tempRealDecodingResultsSigClusterID]=CalculateSignificantClusterSize(IsSignificant(iTrainBin,:));
    RealDecodingResultsSigClusterSize{iTrainBin}=tempRealDecodingResultsSigClusterSize;
    RealDecodingResultsSigClusterID{iTrainBin}=tempRealDecodingResultsSigClusterID;
    %% Calculate the maximum summed cluster size��<2.5th�� for real decoding results with specific training point
    [tempRealDecodingResultsSigLessClusterSize,tempRealDecodingResultsSigLessClusterID]=CalculateSignificantClusterSize(IsSigLessThanChance(iTrainBin,:));
    RealDecodingResultsSigLessClusterSize{iTrainBin}=tempRealDecodingResultsSigLessClusterSize;
%     tempTrainIsSignificant=IsSignificant(iTrainBin,:);
%     tempSigClusterSize=0;
%     tempSigClusterID=[];
%     for iTestBin = 2:TestBinNum%go through each test bin
%         if iTestBin==2&&tempTrainIsSignificant(iTestBin-1)~=0
%             tempSigClusterSize=1;
%             tempSigClusterID=[tempSigClusterID 1];
%         end
%         if tempTrainIsSignificant(iTestBin)~=0&&tempTrainIsSignificant(iTestBin-1)~=0
%             tempSigClusterSize=tempSigClusterSize+1;
%             tempSigClusterID=[tempSigClusterID iTestBin];
%             if iTestBin==TestBinNum
%                 RealDecodingResultsSigClusterSize{iTrainBin}=[RealDecodingResultsSigClusterSize{iTrainBin} tempSigClusterSize];
%                 RealDecodingResultsSigClusterID{iTrainBin}=[RealDecodingResultsSigClusterID{iTrainBin} {tempSigClusterID}];
%             end
%         elseif tempTrainIsSignificant(iTestBin)~=0&&tempTrainIsSignificant(iTestBin-1)==0
%             tempSigClusterSize=1;
%             tempSigClusterID=iTestBin;
%         else
%             if tempSigClusterSize>0
%                 RealDecodingResultsSigClusterSize{iTrainBin}=[RealDecodingResultsSigClusterSize{iTrainBin} tempSigClusterSize];
%                 RealDecodingResultsSigClusterID{iTrainBin}=[RealDecodingResultsSigClusterID{iTrainBin} {tempSigClusterID}];
%             end
%             tempSigClusterSize=0;
%             tempSigClusterID=[];
%         end
%     end
    %% Calculate the maximum summed cluster size for each shuffle decoding with specific training point   
    tempTrainAllShuffleTestIsSignificant=ShuffleIsSignificant(:,iTrainBin,:);
    Size=size(tempTrainAllShuffleTestIsSignificant);
    tempTrainAllShuffleTestIsSignificant=reshape(tempTrainAllShuffleTestIsSignificant,Size(1),Size(3));
    for iShuffle=1:ShuffleDecodingTimes
        ShuffletempTrainIsSignificant=tempTrainAllShuffleTestIsSignificant(iShuffle,:);
        [tempAllSigClusterSize,~]=CalculateSignificantClusterSize(ShuffletempTrainIsSignificant);
        if ~isempty(tempAllSigClusterSize)
            ShuffleSigClusterSize(iTrainBin,iShuffle)=max(tempAllSigClusterSize);
        end
        
%         tempSigClusterSize=0;
%         tempAllSigClusterSize=0;
%         for iTestBin = 2:TestBinNum
%             if iTestBin==2&&ShuffletempTrainIsSignificant(iTestBin-1)==1
%                 tempSigClusterSize=1;
%             end
%             if ShuffletempTrainIsSignificant(iTestBin)==1&&ShuffletempTrainIsSignificant(iTestBin-1)==1
%                 tempSigClusterSize=tempSigClusterSize+1;
%             elseif ShuffletempTrainIsSignificant(iTestBin)==1&&ShuffletempTrainIsSignificant(iTestBin-1)==0
%                 tempSigClusterSize=1;
%             else
%                 if tempSigClusterSize>0
%                     tempAllSigClusterSize=[tempAllSigClusterSize tempSigClusterSize];
%                 end
%                 tempSigClusterSize=0;
%             end
%         end        
    end
    %% perform cluster-based permutation test for larger than 95th percentile
    ShuffleSigClusterSizeNullDis=ShuffleSigClusterSize(iTrainBin,:);
    tempShuffle95PercentileCluterSize=prctile(ShuffleSigClusterSizeNullDis,95);    
    if ~isempty(tempRealDecodingResultsSigClusterSize)
        for iCluster=1:length(tempRealDecodingResultsSigClusterSize)
            if tempRealDecodingResultsSigClusterSize(iCluster)>tempShuffle95PercentileCluterSize%exceed the 95th percentile of shuffle data
                ClusterBasedPermuTestIsSignificant(iTrainBin,tempRealDecodingResultsSigClusterID{iCluster})=1;
            end
        end
    end
    %% perform cluster-based permutation test for lesser than 2.5th percentile
    if IsSingleOrTwoSidesTest~=1
        if ~isempty(tempRealDecodingResultsSigLessClusterSize)%
            for iCluster=1:length(tempRealDecodingResultsSigLessClusterSize)
                if tempRealDecodingResultsSigLessClusterSize(iCluster)>tempShuffle95PercentileCluterSize%exceed the 95th percentile of shuffle data
                    ClusterBasedPermuTestIsSigLessThanChance(iTrainBin,tempRealDecodingResultsSigLessClusterID{iCluster})=1;
                end
            end
        end
    end
end