%this code was used to plot cross-temporal decoding and perform
%cluster-based permutation test for CQDecoding results 
%PlotNDTDecodingResultsPermutationTest CompareMultipleDecodingResults 
%PlotTCTDecodingPermutationTest PlotTCTTargetBin PlotTCT PlotCQDecodingResults 
%CompareTwoTCTDecoding  CQDecodingAna DistractorEffecOnDecoding CompareTwoTCTDiff
clear;clc;close all;

NeuronGroupID=[];

FigureSize=[1.1 1.1];%inch, width/height 1.36 1.3
ColorRange=[35 85];
GroupMarker=[{'Empty'};{'DisTrials'};{'NoDisTri'}];

ColorBarRangeMarker=num2str(ColorRange);
ColorBarRangeMarker=strrep(ColorBarRangeMarker,'  ','-');
ShuffleDecodingTimes=1000;
ShuffleTimesForTest=1000;
DecodingTimes=50;
DecodingTimesForTest=50;

TestTimes=1;

CurrentPath=pwd;
AllPath=genpath(CurrentPath);
SplitPath=strsplit(AllPath,';');
SubPath=SplitPath';
SubPath=SubPath(1:end-1);
SubPath=ExcludeShuffleDir(SubPath);
for iPath=1:size(SubPath,1)%go through each directory
    Path=SubPath{iPath,1};
    cd(Path);
%     StartTime=0;
    
    AllDecodingFile=dir('*Decoding*.mat');%Parameters.mat
    if exist('Shuffle','dir')==7
        ShuffleDecodingDir='Shuffle';
    else
        ShuffleDecodingDir=[];
    end
    AllParametersDecodingFile=dir('*Parameters*.mat');%    
    if size(AllDecodingFile,1)>0
        load(AllParametersDecodingFile.name)
                
        Filename=AllParametersDecodingFile.name;
        GroupID='-NL';
        IsChR=regexpi(Filename,'ChR');
        if ~isempty(IsChR)
            GroupID='-ChR';
        end
        IsNpHR=regexpi(Filename,'NpHR');
        if ~isempty(IsNpHR)
            GroupID='-NpHR';
        end
        AddIndex=regexpi(AllParametersDecodingFile.name,'-Add');
        EndIndex=regexpi(AllParametersDecodingFile.name,'-All Parameters');
        AddGroupID=AllParametersDecodingFile.name(AddIndex:EndIndex-1);
        DayID=[];
        DayMarker=regexpi(AllParametersDecodingFile.name,'-Day');
        if ~isempty(DayMarker)
            DayID=AllParametersDecodingFile.name(DayMarker:DayMarker+5);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% plot Cross temporal decoding results with marker for significant time bin
        RealDecodingResults=mean(DECODING_RESULTS);
        RealDecodingResults=reshape(RealDecodingResults,size(RealDecodingResults,2),size(RealDecodingResults,3));        
        if size(AllDecodingFile,1)>5%construct real decoding from multiple files
            [RealCrossReSampleDecodingResults,RealDecodingResults,RealTCTDecodingStd,TimeBinNumber]...
                =ConstruceRealDecodingResults(AllDecodingFile,DecodingTimes);            
        end        
        
        if ColorRange(1)>=35
%             Color=[255 255 255]/255;
            Color=[237 30 121]/255;
        else
            Color=[255 255 255]/255;
%             Color=[237 30 121]/255;
        end
        BinNum=size(RealDecodingResults,2);
        ProceedingBinNum=bin_width/step_size-1;
        X=-(4-StartTime):step_size/1000:(BinNum*step_size/1000-(4-StartTime))-step_size/1000;
        X=X+step_size/1000/2+ProceedingBinNum*step_size/1000;                 
        TestBinNum=size(RealDecodingResults,2);               
        ShuffleTCTDecodingNullDistribution=zeros(ShuffleDecodingTimes,TestBinNum,TestBinNum);
        if ~isempty(ShuffleDecodingDir)%&&~exist('ClusterBasedPermuTestIsSignificant','var')
            ShuffleTCTDecodingNullDistribution=ConstructShuffleTCTDecoding(ShuffleDecodingDir...
                ,ShuffleDecodingTimes,TestBinNum,step_size,StartTime);
        end        
        %% plot TCT decoding results for several times
        AllClusterBasedPermuTestIsSignificant=cell(1,TestTimes);
        for i=1:TestTimes                     
%             tempDecodingID=(i-1)*DecodingTimesForTest+1:i*DecodingTimesForTest; 
            tempDecodingID=randsample(DecodingTimes,DecodingTimesForTest);
            
            tempDECODING_RESULTS=RealCrossReSampleDecodingResults(tempDecodingID,:,:);
            RealDecodingResults=mean(tempDECODING_RESULTS,1);
            Size=size(RealDecodingResults);
            RealDecodingResults=reshape(RealDecodingResults,Size(2),Size(3));                             
            
%             tempShuffleID=(i-1)*ShuffleTimesForTest+1:i*ShuffleTimesForTest;     
            temp=randperm(ShuffleDecodingTimes);
            tempShuffleID=temp(1:ShuffleTimesForTest);
            
            IsSignificant=zeros(TestBinNum,TestBinNum);
            ClusterBasedPermuTestIsSignificant=zeros(TestBinNum,TestBinNum);
            ClusterBasedPermuTestIsSigLessThanChance=zeros(TestBinNum,TestBinNum);
            ShuffleIsSignificant=zeros(ShuffleDecodingTimes,TestBinNum,TestBinNum);
            ShuffleSigClusterSize=zeros(TestBinNum,ShuffleDecodingTimes);
            RealDecodingResultsSigClusterSize=cell(TestBinNum,1);
            RealDecodingResultsSigClusterID=cell(TestBinNum,1);
            if ~isempty(ShuffleDecodingDir)%&&~exist('ClusterBasedPermuTestIsSignificant','var')
              %% create significant bin index from the null_distribution at each time point based on cluster-based permutation test
                [IsSignificant,ClusterBasedPermuTestIsSignificant,ShuffleIsSignificant,ShuffleSigClusterSize,RealDecodingResultsSigClusterSize...
                    ,RealDecodingResultsSigClusterID,IsSigLessThanChance,ClusterBasedPermuTestIsSigLessThanChance,RealDecodingResultsSigLessClusterSize]...
                    =TCTClusterBasedPermutationTest(RealDecodingResults...
                    ,ShuffleTCTDecodingNullDistribution(tempShuffleID,:,:),TestBinNum,ShuffleTimesForTest,1);
                AllClusterBasedPermuTestIsSignificant{i}=ClusterBasedPermuTestIsSignificant;
            end
            if mod(i,1)==0
                imagesc(X,X,RealDecodingResults*100,ColorRange);%[45 85]
                hold on
                if exist('ClusterBasedPermuTestIsSignificant','var')
                    PlotSigBinNum=length(find(X<=7));
                    PlotSigBinRange=1:PlotSigBinNum;
                    AllIsSignificantMatrix=zeros(size(RealDecodingResults));
                    AllIsSignificantMatrix(PlotSigBinRange,PlotSigBinRange)=AllIsSignificantMatrix(PlotSigBinRange,PlotSigBinRange)...
                        +ClusterBasedPermuTestIsSignificant(PlotSigBinRange,PlotSigBinRange);
                    
                    contour(X,X,AllIsSignificantMatrix,[1 1],'-','color',Color,'linewidth',2)
                    
                    AllIsSigLessThanChanceMatrix=zeros(size(RealDecodingResults));
                    AllIsSigLessThanChanceMatrix(PlotSigBinRange,PlotSigBinRange)=AllIsSigLessThanChanceMatrix(PlotSigBinRange,PlotSigBinRange)...
                        +ClusterBasedPermuTestIsSigLessThanChance(PlotSigBinRange,PlotSigBinRange);
                    contour(X,X,AllIsSigLessThanChanceMatrix,[1 1],'-','color',[1 0 1],'linewidth',2)
                end
                significant_event_times=[0 OdorMN OdorMN+DelayMN 2*OdorMN+DelayMN 2*OdorMN+DelayMN+ResponseMN 2*OdorMN+DelayMN+ResponseMN+WaterMN];
                for iEvent = 1:length(significant_event_times)
                    plot([significant_event_times(iEvent), significant_event_times(iEvent)], get(gca, 'YLim'),'--k','linewidth',1)
                    plot(get(gca, 'XLim'), [significant_event_times(iEvent), significant_event_times(iEvent)],'--k','linewidth',1)
                end
                if ~isempty(regexpi(TitleName,'DisTrials'))&&isempty(regexpi(TitleName,'NoDisTrials'))
                    plot([4 4], get(gca, 'YLim'),'--','color',[1 0 1],'linewidth',1.5)
                    plot([4+1 4+1], get(gca, 'YLim'),'--','color',[1 0 1],'linewidth',1.5)
                    plot(get(gca, 'XLim'), [4 4],'--','color',[1 0 1],'linewidth',1.5)
                    plot(get(gca, 'XLim'), [4+1 4+1],'--','color',[1 0 1],'linewidth',1.5)
                    %4-ProceedingBinNum*step_size/1000+0.05
                end
                colorbar('ytick',[30 40 50 60 70 80],'yticklabel',[30 40 50 60 70 80])
                set(gca,'xtick',[0 2 4 6 8 10 12 14], 'XTickLabel', [0 2 4 6 8 10 12 14],'ytick',[0 2 4 6 8 10 12 14], 'yTickLabel', [0 2 4 6 8 10 12 14],'TickLength',[0.025, 0.025],'linewidth',1);%add by CQ
                axis([-0.5 DelayMN+OdorMN*2+0.5 -0.5 DelayMN+OdorMN*2+0.5])
                xlabel('Test time (s)','fontsize',12)
                ylabel('Train time (s)','fontsize',12)
                axis xy
                title(TitleName)
                cd(SubPath{1})
                saveas(gcf,[TitleName '-' ColorBarRangeMarker NeuronGroupID '-Test-' num2str(i)],'fig')%
                saveas(gcf,[TitleName '-' ColorBarRangeMarker NeuronGroupID '-Test-' num2str(i)],'png')%
                %% save in specific size for Adobe Illustrator
                %         ResizeFigureForPaper([TitleName '-' ColorBarRangeMarker],FigureSize,[-0.5 DelayMN+OdorMN*2+0.5 -0.5 DelayMN+OdorMN*2+0.5],1,[-2 0 2 4 6 8 10 12],[-2 0 2 4 6 8 10 12])
                close all
            end
        end
        save(['CQCrossTemporalDecodingWithPermuTest' GroupID AddGroupID NeuronGroupID DayID],'TitleName','RealDecodingResults'...
            ,'RealTCTDecodingStd','X','ClusterBasedPermuTestIsSignificant','IsSignificant','ShuffleTCTDecodingNullDistribution'...
            ,'bin_width','step_size','ShuffleSigClusterSize','RealDecodingResultsSigClusterSize','RealDecodingResultsSigClusterID','StartTime'...
            ,'ShuffleDecodingTimes','OdorMN','DelayMN','ResponseMN','WaterMN','ITIMN','GroupID','TestTimes'...
            ,'AllClusterBasedPermuTestIsSignificant','ShuffleTimesForTest','RealCrossReSampleDecodingResults')
    end
end