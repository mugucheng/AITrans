%the code was used to calculate the decoding efficiency(template matching)
%AllUnitsOdorSelectivityAna NDTDecoding CQDecodingOld DecodingAnaAccordingToPerformance
%CQDecodingWithDistractorAna PlotCQDecodingResults  %PlotCQTCTDecoding
addpath(genpath('/gpfsdata/home/qcheng/Decoding/'))%New ION computing center
% addpath(genpath('D:\CQ\Matlab codes'))
clear;clc;close all
TargetDayID=[{[1 2 3 4 5]}];%;{[5]}define the group days used to perform decoding analysis
% TargetDayID=[{[2]};{[2]};{[3]};{[4 5]}];%;{[5]}define the group days used to perform decoding analysis
WorkerNumber=1;

TargetBrainID='AI';%define the brain area for summary
UnitSummaryFile=dir(['*' TargetBrainID '-DPA-AllUnitsSummary*.mat']);
for iFile=[1]%go through each group of data
    Filename=UnitSummaryFile(iFile).name(1:end-4);
    disp(Filename)
    disp(datetime)
    
    num_neuron_ForDecoding=100;% if IsCorrectOrErrorOrAllTrials=4, NL-430; ChR-380; NpHR-340
    num_trial_ForEachCondition=80;
    IsCorrectOrErrorOrAllTrials=3;%1 for correct trials, 2 for error trials , 3 for all trials, 4 for correct trials as template, error trials as test
    GroupNum=1;
    NullDistributionNum=2;
    num_resample_runs=2;%define the decoding times
    
    IsShffleDecoding=0;
    IsCalculateTCTDecodingResults=1;
    AddSustainedNeuronWithSigBinNum=[6]; % add selective neurons to non-selective pools with target bin number having sustained
    OnlyWithOrAddTargetSigBinNum=1; % 1 for only with target neurons with specific sig bins, 2 for add  target neurons to non-selective neurons
    % 1 second odor selectivity  during delay period, 0 for non-selective neurons
    for ExcludeTransientSustainedNeu=[0] % 0 for not exclude, 1 for excluding transient neurons, 2 for exclude sustained neurons,3 only with Transient neruons, 4 noly with Sustained neurons
        ExcludeNeuronWithReversedOdorSelectivity=0; %1 delay reversed selec neu; 2 sample-delay reversed selec neu; 3 both 1 and 2;4 for only with reversed neurons
        % ChR-569-31=538; NL:704-13=691; NpHR:451-5=446; %delay reversed selective neurons
        % ChR-569-42=527; NL-704-29=675; NpHR-451-19=432;$Sample-Delay reversed selective neurons
        % ChR-569-54=515; NL:704-32=672; NpHR-451-20=431;%3 for both
        
        PairOrNonPairTrials=3;%1 for pairing trials, 2 for non-pairing trials,3 for all trials
        bin_width=500;%define the bin width for each sliding window
        step_size=100;%ms
        StartTime=2;%start from 2 second after to 4s baseline(which means 4-2=2s before the sample odor)
        NotComputeLastSecondNum=0;
        CellType=1;% 1 for all neurons, 2 for pyramidal neurons, 3 for interneurons
        DecodingForSamTestDecisionTrialType=1;% Decoding for 1-sample odor,2-test odor, 3-decision(FC or CR in nonpair trials), 4-trial type(Pair-Nonpair)
        IsNormalizedData=1;
        
        GroupID='-NL';
        IsChR=regexpi(Filename,'ChR');
        if ~isempty(IsChR)
            GroupID='-ChR';
        end
        IsNpHR=regexpi(Filename,'NpHR');
        if ~isempty(IsNpHR)
            GroupID='-NpHR';
        end
        load(Filename);
        tempTotalUnitSplitData=TotalUnitSplitData;
        TimeGain=tempTotalUnitSplitData.TimeGain{1}(1);      
        
        %% get the training day ID
        [MiceID,TargetTrainingDay]=GetTrainingDay(TotalUnitSplitData);
        %get the performance and neuron ID for each training day
        DayBasedPerformanceNeuron=DayBasedPerAndNeuronInfo(TotalUnitSplitData,TargetTrainingDay);
        %get all the neuron index in the traget training day
        [NeuronIndexInEachTrainingDay,MiceBasedPerformance]=GetNeuronIndexInEachTrainingDay(DayBasedPerformanceNeuron,MiceID);
        
        for iTargetDay=1:length(TargetDayID)%go through each target day group
            TrainingDayID=ConstructDayID(TargetDayID{iTargetDay});
            TrainingDayID=regexprep(TrainingDayID,'  ','-','ignorecase');
           %% extract the neurons in this specific training day
            TargetNeuronID=NeuronIndexInEachTrainingDay(1,TargetDayID{iTargetDay});
            tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,vertcat(TargetNeuronID{:}));
            
           %% extract the neurons in this specific training day                 
            LaserPhase=unique(tempTotalUnitSplitData.TrialLaserDelay{1}(:,2));%2 for laser in block design
            for IsLaser=1:length(LaserPhase)
                IsLaserTrial=LaserPhase(IsLaser);
                
                TimeGain=tempTotalUnitSplitData.TimeGain{1}(1);
                SPlen=min(vertcat(tempTotalUnitSplitData.ShortSPlen{:}));
                MeanTrialLength=SPlen/TimeGain;
                
                if ExcludeNeuronWithReversedOdorSelectivity>0||ExcludeTransientSustainedNeu>0
                    [NeuronIDWithDelayReversedOdorSelectivity,NonSelectiveNeuID,SampleDelayReversedSelectivityNeuID,DelaySigBinNum]...
                        =FilterNeuronIDWithReversedOdorSelectivity(tempTotalUnitSplitData,TimeGain,OdorMN,DelayMN);
                    BothSwithNeuID=union(NeuronIDWithDelayReversedOdorSelectivity,SampleDelayReversedSelectivityNeuID);
                    
                    if ExcludeNeuronWithReversedOdorSelectivity==1
                        tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,NeuronIDWithDelayReversedOdorSelectivity);
                        disp(['---- Excluded Neurons With reversed odor selectivity-' num2str(length(NeuronIDWithDelayReversedOdorSelectivity)) '----'])
                    elseif ExcludeNeuronWithReversedOdorSelectivity==2
                        tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,SampleDelayReversedSelectivityNeuID);
                        disp(['---- Excluded Neurons With sample-delay reversed odor selectivity-' num2str(length(SampleDelayReversedSelectivityNeuID)) '----'])
                    elseif ExcludeNeuronWithReversedOdorSelectivity==3
                        AllReversedSelecNeuID=union(NeuronIDWithDelayReversedOdorSelectivity,SampleDelayReversedSelectivityNeuID);
                        tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,AllReversedSelecNeuID);
                        AllReversedSelectiveNeuNum=length(AllReversedSelecNeuID);
                        disp(['---- Excluded delay reversed selec and sample-delay reversed selec neu-' num2str(AllReversedSelectiveNeuNum) '----'])
                    elseif ExcludeNeuronWithReversedOdorSelectivity==4
                        AllReversedSelecNeuID=union(NeuronIDWithDelayReversedOdorSelectivity,SampleDelayReversedSelectivityNeuID);
                        tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,AllReversedSelecNeuID);
                        disp(['---- Decoding only With reversed odor selectivity-' num2str(length(AllReversedSelecNeuID)) '----'])
                    end
                    TransientNeuID=find(DelaySigBinNum>=1&DelaySigBinNum<=4);
                    SustainedNeuID=find(DelaySigBinNum==5);
                    
                    %TransientNeuID=setdiff(TransientNeuID,BothSwithNeuID);
                    %SustainedNeuID=setdiff(SustainedNeuID,BothSwithNeuID);
                    if ExcludeTransientSustainedNeu==1%exclude transient selective neurons
                        tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,TransientNeuID);
                        disp(['-----Exclude transient selective neurons-' num2str(length(TransientNeuID)) '-----'])
                    elseif ExcludeTransientSustainedNeu==2%exclude sustained selective neurons
                        tempTotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(tempTotalUnitSplitData,SustainedNeuID);
                        disp(['-----Exclude sustained selective neurons-' num2str(length(SustainedNeuID)) '-----'])
                    elseif ExcludeTransientSustainedNeu==3%Only with transient selective neurons
                        tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,TransientNeuID);
                        disp(['-----Only With transient selective neurons-' num2str(length(TransientNeuID)) '-----'])
                    elseif ExcludeTransientSustainedNeu==4%Only with sustained selective neurons
                        tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,SustainedNeuID);
                        disp(['-----Only With SustainedNeuID selective neurons-' num2str(length(SustainedNeuID)) '-----'])
                    end
                end
                %%
                if CellType>1%identify the cell type with the waveform,1 for all neurons, 2 for pyramidal neurons, 3 for interneurons
                    AllWaveForm=tempTotalUnitSplitData.WaveForm;
                    Threshold=350;%threshold seperate fast spiking interneuron and pyramidal neurons
                    [AllPeakTroughDuration,FSIID,PCID]=IdentifyCellTypeBasedOnWaveform(AllWaveForm,Threshold);
                    if CellType==2%2 for pyramidal neurons
                        tempTotalUnitSplitData=FilterTotalUnitSplitData(tempTotalUnitSplitData,PCID);
                    elseif CellType==3%3 for interneurons
                        tempTotalUnitSplitData=FilterTotalUnitSplitData(tempTotalUnitSplitData,FSIID);
                    end
                end
                %% add neurons with sustained odor selectivty to no selective neurons
                TotalSingleUnitNum=length(tempTotalUnitSplitData.AllSequentialAllSP);
                IsSustainedOdorSelectiveNeuron=zeros(TotalSingleUnitNum,5);
                TargetNeuronIDWithSpecificSigBin=[];
                if min(AddSustainedNeuronWithSigBinNum)>=0&&max(AddSustainedNeuronWithSigBinNum)<=5
                    disp('-----Pre-processing the odor selectivity for each neuron -----')
                    [TargetNeuronID,IsSustainedOdorSelectiveNeuron,DelaySigBinNum,TargetNeuronIDWithSpecificSigBin,NeuronNumWithDiffSig1SecondBin]...
                        =ConstructNeuronIDWithSpecificSustainedNeu(tempTotalUnitSplitData,TimeGain,DelayMN,DecodingForSamTestDecisionTrialType...
                        ,AddSustainedNeuronWithSigBinNum,IsLaserTrial,3,PairOrNonPairTrials);
                    disp(['-----Target sig neuron number-' num2str(length(TargetNeuronIDWithSpecificSigBin)) '-----'])
                    
                    if OnlyWithOrAddTargetSigBinNum==1% only with neurons with specific sig bin during delay
                        TargetNeuronID=TargetNeuronIDWithSpecificSigBin;
                    elseif OnlyWithOrAddTargetSigBinNum==2% target sig neurons with non-selective neurons
                        TargetNeuronID=TargetNeuronID;
                    end
                else
                    TargetNeuronID=1:TotalSingleUnitNum;
                end
                TotalSingleUnitNum=length(TargetNeuronID);
                
                disp(['---- GroupNum-' num2str(GroupNum) '-TotalNullDistributionNum-' num2str(NullDistributionNum) '----'] )
                TitleName=ConstructDecodingTitle(TargetBrainID,DecodingForSamTestDecisionTrialType,IsLaserTrial,IsShffleDecoding...
                    ,num_neuron_ForDecoding,IsNormalizedData,num_resample_runs,num_trial_ForEachCondition,num_trial_ForEachCondition,[],0,0,GroupID...
                    ,0,TrainingDayID,bin_width,IsCorrectOrErrorOrAllTrials,CellType,AddSustainedNeuronWithSigBinNum...
                    ,ExcludeTransientSustainedNeu,ExcludeNeuronWithReversedOdorSelectivity,IsCalculateTCTDecodingResults);
                disp(TitleName)
                %% Construct the raw trial matrix
                disp(['-----Step 1 Construct raw data Total Neuron Number-' num2str(TotalSingleUnitNum) '-----'])
                TrialBinnedFR=cell(1,TotalSingleUnitNum);
                AllNeuronTrialNumber=zeros(2,TotalSingleUnitNum);
                AllNeuSampleTrialID=cell(2,TotalSingleUnitNum);
                for iNeuron = 1:TotalSingleUnitNum% go through each neuron
                    tempNeuronID=TargetNeuronID(iNeuron);
                    SequentialAllSP=tempTotalUnitSplitData.AllSequentialAllSP{tempNeuronID};
                    TrialsJudgement=tempTotalUnitSplitData.TrialsJudgement{tempNeuronID}(1:size(SequentialAllSP,2),:);
                    TrialLaserDelay=tempTotalUnitSplitData.TrialLaserDelay{tempNeuronID}(1:size(SequentialAllSP,2),:);
                    
                    if IsLaserTrial==0%no laser trials
                        SequentialAllSP=SequentialAllSP(:,TrialLaserDelay(:,2)==0);
                        TrialsJudgement=TrialsJudgement(TrialLaserDelay(:,2)==0,:);
                    else
                        SequentialAllSP=SequentialAllSP(:,TrialLaserDelay(:,2)~=0);
                        TrialsJudgement=TrialsJudgement(TrialLaserDelay(:,2)~=0,:);
                    end
                    [TrialIndex1,TrialIndex2,tempTrialBinnedFR] =ConstrucSingleNeuForDecoding...
                        (DecodingForSamTestDecisionTrialType,TrialsJudgement,IsCorrectOrErrorOrAllTrials...
                        ,SequentialAllSP,bin_width,step_size,MeanTrialLength,1,NotComputeLastSecondNum,StartTime);
                    
                    TrialBinnedFR{1,iNeuron}=tempTrialBinnedFR;
                    AllNeuSampleTrialID(:,iNeuron)=[{TrialIndex1};{TrialIndex2}];
                    AllNeuronTrialNumber(:,iNeuron)=[length(TrialIndex1);length(TrialIndex2)];
                end
                [~,TooFewTrialNeuronIndex]=find(min(AllNeuronTrialNumber)<num_trial_ForEachCondition);
                TrialBinnedFR(:,TooFewTrialNeuronIndex)=[];
                AllNeuSampleTrialID(:,TooFewTrialNeuronIndex)=[];
                disp(['-----Neuron Number With Enough Trial-' num2str(length(TrialBinnedFR)) '->=' num2str(num_trial_ForEachCondition) '-----'])
                %% calculate the decoding accuracy by using correct tirals
                disp('-----Step 2 Start decoding analysis-----')
                disp(datetime)
                if WorkerNumber>1
                    poolobj = gcp('nocreate'); % If no pool, do not create new one.
                    if isempty(poolobj)
                        myCluster=parcluster('local'); myCluster.NumWorkers=WorkerNumber; parpool(myCluster,WorkerNumber)
                    end                    
                    for iNullDis=1:NullDistributionNum
                        f(iNullDis) = parfeval(@CQCrossValidationTest,1,TrialBinnedFR,AllNeuSampleTrialID,num_trial_ForEachCondition...
                            ,num_neuron_ForDecoding,IsNormalizedData,num_resample_runs,IsShffleDecoding,IsCalculateTCTDecodingResults);
                    end
                    for iNullDis=1:NullDistributionNum
                        [~,DECODING_RESULTS] = fetchNext(f);  % Collect the results as they become available.
                        save(['CQCV' TitleName '-' num2str(GroupNum) '-' num2str(iNullDis)], 'DECODING_RESULTS','-v7.3');
                    end
                else
                    for iNullDis=1:NullDistributionNum
                        DECODING_RESULTS = CQCrossValidationTest(TrialBinnedFR,AllNeuSampleTrialID,num_trial_ForEachCondition...
                            ,num_neuron_ForDecoding,IsNormalizedData,num_resample_runs,IsShffleDecoding,IsCalculateTCTDecodingResults);
                        save(['CQCV' TitleName '-' num2str(GroupNum) '-' num2str(iNullDis)], 'DECODING_RESULTS','-v7.3');
                    end
                end
                BinNum=size(TrialBinnedFR{1},2);
                ProceedingBinNum=bin_width/step_size;
                X=-(4-StartTime):step_size/1000:(BinNum*step_size/1000-(4-StartTime))-step_size/1000;
                X=X+ProceedingBinNum*step_size/1000+step_size/1000/2;
                save(['CQCV' TitleName '-All Parameters'],'TitleName','DECODING_RESULTS','TrialBinnedFR','AllNeuSampleTrialID','AllNeuronTrialNumber'...
                    ,'num_trial_ForEachCondition','TimeGain','OdorMN','DelayMN','ResponseMN','WaterMN','ITIMN','num_resample_runs'...
                    ,'num_trial_ForEachCondition','SPlen','bin_width','step_size','Filename','num_neuron_ForDecoding','NotComputeLastSecondNum'...
                    ,'StartTime','X','AddSustainedNeuronWithSigBinNum','ExcludeNeuronWithReversedOdorSelectivity')
            end
        end
    end
    disp(['---' Filename '-Computing End---'])
end