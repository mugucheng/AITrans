function [TempOdorSelectivity]=SecondBasedRankSumTest(ATrials,BTrials,TimeGain,Start,End,DelayBinSize,DelayStepSize,WhetherBonferroniCorr)

if nargin==5
    DelayBinSize=1;
    DelayStepSize=1;
    WhetherBonferroniCorr=1;
end

HypothesesNum=(5-DelayBinSize)/DelayStepSize+1;%Delay Bin Number
if WhetherBonferroniCorr==1
    BonferroniCorrectionPValue=0.05/HypothesesNum;
else
    BonferroniCorrectionPValue=0.05;
end
PreDelayBinNum=(1-Start-DelayStepSize)/DelayStepSize+1;

BinNum=(round(End)-round(Start)-DelayBinSize)/DelayStepSize+1;
TempOdorSelectivity=zeros(5,BinNum);
StartBin=(Start-(-4))*TimeGain;
for iBin=1:BinNum%go through each 1 second period    
    tempEventPeriod=StartBin+(iBin-1)*DelayStepSize*TimeGain+1:StartBin+(iBin-1)*DelayStepSize*TimeGain+DelayBinSize*TimeGain;    
    
    [p2,h,MeanAFR,MeanBFR,SelectivityIndex]=RankSumTest(ATrials,BTrials,tempEventPeriod,TimeGain);
    if iBin>PreDelayBinNum
        if p2<BonferroniCorrectionPValue
            h=1;
        else
            h=0;
        end
    end
    TempOdorSelectivity(1,iBin)=p2;
    TempOdorSelectivity(2,iBin)=SelectivityIndex;
    TempOdorSelectivity(3,iBin)=h;
    TempOdorSelectivity(4,iBin)=MeanAFR;
    TempOdorSelectivity(5,iBin)=MeanBFR;
end