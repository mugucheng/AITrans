function [p,h,MeanFR1,MeanFR2,SelectivityIndex]=RankSumTest(Trials1,Trials2,EventPeriod,TimeGain,SPlen,EventPeriod2)

if nargin<6
    EventPeriod2=EventPeriod;
end
if nargin<5
    EventPeriod2=EventPeriod;
    SPlen=210;
end

Trials1=Trials1(1,:);
SpikeTrain1=cellfun(@(x) x(2:SPlen),Trials1,'uniformoutput',0);
SpikeTrain1=vertcat(SpikeTrain1{:});
TargetFR1=mean(SpikeTrain1(:,(EventPeriod)),2)*TimeGain;
Trials2=Trials2(1,:);
SpikeTrain2=cellfun(@(x) x(2:SPlen),Trials2,'uniformoutput',0);
SpikeTrain2=vertcat(SpikeTrain2{:});
TargetFR2=mean(SpikeTrain2(:,(EventPeriod2)),2)*TimeGain;

[p,h]=ranksum(TargetFR1,TargetFR2);

MeanFR1=mean(TargetFR1);
MeanFR2=mean(TargetFR2);
SelectivityIndex=(MeanFR1-MeanFR2)/(MeanFR1+MeanFR2);
