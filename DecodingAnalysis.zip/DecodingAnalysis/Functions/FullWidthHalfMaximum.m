function [FWHM,LeftPoint,RightPoint,Threshold]=FullWidthHalfMaximum(Wave)
%Threshold =(min(Wave)-Wave(1))/2+Wave(1);
Threshold =min(Wave)/2;
LeftLeanCrossPoint=find([Wave 10000]<Threshold & [-10000 Wave]>Threshold);
RightLeanCrossPoint=find([Wave -10000]>Threshold & [10000 Wave]<Threshold);
[~,I]=min(Wave);
LeftCrossPoint=LeftLeanCrossPoint(LeftLeanCrossPoint<I);
RightCrossPoint=RightLeanCrossPoint(RightLeanCrossPoint>I);
LeftPoint=[];RightPoint=[];
if ~isempty(LeftCrossPoint) && ~isempty(RightCrossPoint)
    LeftPoint=max(LeftCrossPoint);
    RightPoint=min(RightCrossPoint);
    FWHM=(RightPoint-(Wave(RightPoint)-Threshold)/((Wave(RightPoint)-Wave(RightPoint-1))))-(LeftPoint-((Wave(LeftPoint)-Threshold)/(Wave(LeftPoint)-Wave(LeftPoint-1))));
elseif ~isempty(RightCrossPoint)
    RightPoint=RightCrossPoint(1);
    FWHM=((RightPoint-((Wave(RightPoint)-Threshold)/(Wave(RightPoint)-Wave(RightPoint-1))))-I)*2;
elseif ~isempty(LeftCrossPoint)
    LeftPoint=LeftCrossPoint(length(LeftCrossPoint));
    FWHM=(I-(((Wave(LeftPoint)-Threshold)/(Wave(LeftPoint)-Wave(LeftPoint+1)))+LeftPoint))*2;
else
    FWHM=length(Wave);
end