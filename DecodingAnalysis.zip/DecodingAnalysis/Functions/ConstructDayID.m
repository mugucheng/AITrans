function DayID=ConstructDayID(tempTargetDayID)

DayID='Day';
for iDay=1:length(tempTargetDayID)
  DayID=[DayID '-' num2str(tempTargetDayID(iDay))];
end
