function OdorSelectivity=TestOdorSelectiviey(TotalUnitSplitData,iNeuron,DelayMN,TimeGain,SampleOrTestOdorSelectivity)

SequentialAllSP=TotalUnitSplitData.AllSequentialAllSP{iNeuron};
TrialsJudgement=TotalUnitSplitData.TrialsJudgement{iNeuron}(1:size(SequentialAllSP,2),:);
%TrialLaserDelay=TotalUnitSplitData.TrialLaserDelay{iNeuron}(1:size(SequentialAllSP,2),:);

ATrialIndex= TrialsJudgement(:,SampleOrTestOdorSelectivity+1)==1;%&TrialLaserDelay(:,2)==0
BTrialIndex= TrialsJudgement(:,SampleOrTestOdorSelectivity+1)==2;%&TrialLaserDelay(:,2)==0
ATrials=SequentialAllSP(:,ATrialIndex);
BTrials=SequentialAllSP(:,BTrialIndex);
%%
OdorSelectivity=struct('NoLaserOdorSelectivity',[]);
%perform significance test second by second
[TempOdorSelectivity]=SecondBasedRankSumTest(ATrials,BTrials,TimeGain,0,DelayMN);
OdorSelectivity.NoLaserOdorSelectivity=TempOdorSelectivity;
