function tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,tempNeuronID)
% 
% tempTotalUnitSplitData=struct('BrainID',[],'DataID',[],'UnitID',[],'FirstOdor',[],'SecondOdor',[],'SpikeTime',[]);
% tempTotalUnitSplitData.BrainID=TotalUnitSplitData.BrainID(tempNeuronID);
% tempTotalUnitSplitData.DataID=TotalUnitSplitData.DataID(tempNeuronID);
% tempTotalUnitSplitData.UnitID=TotalUnitSplitData.UnitID(tempNeuronID);
% tempTotalUnitSplitData.FirstOdor=TotalUnitSplitData.FirstOdor(tempNeuronID);
% tempTotalUnitSplitData.SecondOdor=TotalUnitSplitData.SecondOdor(tempNeuronID);
% tempTotalUnitSplitData.SpikeTime=TotalUnitSplitData.SpikeTime(tempNeuronID);
% tempTotalUnitSplitData.TrialsJudgement=TotalUnitSplitData.TrialsJudgement;

tempTotalUnitSplitData=struct('BrainID',[],'DataID',[],'UnitID',[],'AllSequentialAllSP',[],'SpikeTime',[],'FiringRate',[]...
    ,'MeanFR',[],'WaveForm',[],'TrialLaserDelay',[],'TrialsJudgement',[],'TrialSplit',[],'GNGTrialType',[],'TetrodeList',[],...
    'SingleUnitTetrodeList',[],'ShortSPlen',[],'RuleSequence',[],'AutoCorr',[],'TimeGain',[],'FirstOdor',[],'SecondOdor',...
    [],'DelayMeanTrialLenMN',[],'Laser',[],'TaskType',[],'NewLick',[],'DistractorTrialInfo',[],'Distractors',[]);

tempTotalUnitSplitData.BrainID=TotalUnitSplitData.BrainID(tempNeuronID);
tempTotalUnitSplitData.DataID=TotalUnitSplitData.DataID(tempNeuronID);
tempTotalUnitSplitData.UnitID=TotalUnitSplitData.UnitID(tempNeuronID);
tempTotalUnitSplitData.AllSequentialAllSP=TotalUnitSplitData.AllSequentialAllSP(tempNeuronID);
tempTotalUnitSplitData.SpikeTime=TotalUnitSplitData.SpikeTime(tempNeuronID);
tempTotalUnitSplitData.FiringRate=TotalUnitSplitData.FiringRate(tempNeuronID);
tempTotalUnitSplitData.MeanFR=TotalUnitSplitData.MeanFR(tempNeuronID);
tempTotalUnitSplitData.WaveForm=TotalUnitSplitData.WaveForm(tempNeuronID);
tempTotalUnitSplitData.TrialLaserDelay=TotalUnitSplitData.TrialLaserDelay(tempNeuronID);
tempTotalUnitSplitData.TrialsJudgement=TotalUnitSplitData.TrialsJudgement(tempNeuronID);
tempTotalUnitSplitData.TrialSplit=TotalUnitSplitData.TrialSplit(tempNeuronID);
tempTotalUnitSplitData.TetrodeList=TotalUnitSplitData.TetrodeList(tempNeuronID);
tempTotalUnitSplitData.SingleUnitTetrodeList=TotalUnitSplitData.SingleUnitTetrodeList(tempNeuronID);
tempTotalUnitSplitData.ShortSPlen=TotalUnitSplitData.ShortSPlen(tempNeuronID);
% tempTotalUnitSplitData.RuleSequence=TotalUnitSplitData.RuleSequence(tempNeuronID);
tempTotalUnitSplitData.AutoCorr=TotalUnitSplitData.AutoCorr(tempNeuronID);
tempTotalUnitSplitData.TimeGain=TotalUnitSplitData.TimeGain(tempNeuronID);
tempTotalUnitSplitData.FirstOdor=TotalUnitSplitData.FirstOdor(tempNeuronID);
tempTotalUnitSplitData.SecondOdor=TotalUnitSplitData.SecondOdor(tempNeuronID);
tempTotalUnitSplitData.DelayMeanTrialLenMN=TotalUnitSplitData.DelayMeanTrialLenMN(tempNeuronID);
if isfield(TotalUnitSplitData, 'Laser')&&~isempty(TotalUnitSplitData.Laser)
    tempTotalUnitSplitData.Laser=TotalUnitSplitData.Laser(tempNeuronID);
end
if isfield(TotalUnitSplitData, 'NewLick')&&~isempty(TotalUnitSplitData.NewLick)
    tempTotalUnitSplitData.NewLick=TotalUnitSplitData.NewLick(tempNeuronID);
end
tempTotalUnitSplitData.TaskType=TotalUnitSplitData.TaskType;
if isfield(TotalUnitSplitData, 'DistractorTrialInfo')&&~isempty(TotalUnitSplitData.DistractorTrialInfo)
    tempTotalUnitSplitData.DistractorTrialInfo=TotalUnitSplitData.DistractorTrialInfo(tempNeuronID);
    tempTotalUnitSplitData.Distractors=TotalUnitSplitData.Distractors(tempNeuronID);
end
