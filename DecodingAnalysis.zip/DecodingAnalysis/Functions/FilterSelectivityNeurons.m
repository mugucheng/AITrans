%This code was used to select the neurons with significant delay period
%sample odor selectivity
function AllUnitOdorSelectivity=FilterSelectivityNeurons(TotalUnitSplitData,DelayMN,TimeGain,SampleOrTestOdorSelectivity)

AllUnitOdorSelectivity=struct('NLIsSignificant',[],'NLOdorSelectivityIndex',[],'NLPValue',[]);
for iNeuron=1:size(TotalUnitSplitData.UnitID,1)%go through each unit
    %%
    %Plot firing rate curve of trials grouped accroding to the identity of the first odor and do statistical test
    OdorSelectivity=TestOdorSelectiviey(TotalUnitSplitData,iNeuron,DelayMN,TimeGain,SampleOrTestOdorSelectivity);
    
    AllUnitOdorSelectivity.NLIsSignificant=[AllUnitOdorSelectivity.NLIsSignificant;OdorSelectivity.NoLaserOdorSelectivity(3,:)];
    AllUnitOdorSelectivity.NLOdorSelectivityIndex=[AllUnitOdorSelectivity.NLOdorSelectivityIndex;OdorSelectivity.NoLaserOdorSelectivity(2,:)];
    AllUnitOdorSelectivity.NLPValue=[AllUnitOdorSelectivity.NLPValue;OdorSelectivity.NoLaserOdorSelectivity(1,:)];
end