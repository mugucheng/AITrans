function [tempTotalUnitSplitData,NeuronIndexWithDelayOdorSelectivity,AllUnitOdorSelectivity]...
    =PickUpSignificantSelectiveNeurons(TotalUnitSplitData,DelayMN,TimeGain)

AllUnitOdorSelectivity=FilterSelectivityNeurons(TotalUnitSplitData,DelayMN,TimeGain,1);%get the delay sample odor selectivity index for all neurons
[NeuronIndexWithDelayOdorSelectivity,~]=find(AllUnitOdorSelectivity.NLIsSignificant(:,2:end)==1);
NeuronIndexWithDelayOdorSelectivity=unique(NeuronIndexWithDelayOdorSelectivity);

tempTotalUnitSplitData=FilterTotalUnitSplitData(TotalUnitSplitData,NeuronIndexWithDelayOdorSelectivity);

