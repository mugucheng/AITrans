function [Results,Data,TrialNum]=GetResultsFromTrials(Trials,TrialNumInBlock)
 
tempRule=unique(Trials(:,1));
ComplimentTrialNum=ceil(size(Trials,1)/TrialNumInBlock)*TrialNumInBlock-size(Trials,1);
if ComplimentTrialNum>0
    Trials=[Trials; zeros(ComplimentTrialNum,size(Trials,2))];
end
if length(tempRule)==1
    Trials(:,1)=tempRule;
else
    Trials(:,1)=5;
end
Data=zeros(ceil(size(Trials,1)/TrialNumInBlock),7);
TrialNum=zeros(ceil(size(Trials,1)/TrialNumInBlock),1);
 for iBlock=1:ceil(size(Trials,1)/TrialNumInBlock)%go through each block
     Data(iBlock,1)=round(mean(Trials((iBlock-1)*TrialNumInBlock+1:iBlock*TrialNumInBlock,1)));
     Data(iBlock,2)=iBlock;
     Data(iBlock,3)=length(find(Trials((iBlock-1)*TrialNumInBlock+1:iBlock*TrialNumInBlock,end-1)==1));
     Data(iBlock,4)=length(find(Trials((iBlock-1)*TrialNumInBlock+1:iBlock*TrialNumInBlock,end-1)==2));
     Data(iBlock,5)=length(find(Trials((iBlock-1)*TrialNumInBlock+1:iBlock*TrialNumInBlock,end-1)==3));
     Data(iBlock,6)=length(find(Trials((iBlock-1)*TrialNumInBlock+1:iBlock*TrialNumInBlock,end-1)==4));
     Data(iBlock,7)=round((Data(iBlock,3)+Data(iBlock,6))/sum(Data(iBlock,3:6))*100);
     TrialNum(iBlock,1)=Data(iBlock,3)+Data(iBlock,4)+Data(iBlock,5)+Data(iBlock,6);
 end
Results=[Data TrialNum];
     