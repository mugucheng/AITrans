function TotalUnitSplitData=DelateNeuronsInTotalUnitSplitData(TotalUnitSplitData,tempPhasesNeuronID)

TotalUnitSplitData.BrainID(tempPhasesNeuronID)=[];
TotalUnitSplitData.DataID(tempPhasesNeuronID)=[];
TotalUnitSplitData.UnitID(tempPhasesNeuronID)=[];
TotalUnitSplitData.AllSequentialAllSP(tempPhasesNeuronID)=[];
TotalUnitSplitData.SpikeTime(tempPhasesNeuronID)=[];
TotalUnitSplitData.FiringRate(tempPhasesNeuronID)=[];
TotalUnitSplitData.MeanFR(tempPhasesNeuronID)=[];
TotalUnitSplitData.WaveForm(tempPhasesNeuronID)=[];
TotalUnitSplitData.TrialLaserDelay(tempPhasesNeuronID)=[];
TotalUnitSplitData.TrialsJudgement(tempPhasesNeuronID)=[];
TotalUnitSplitData.TrialSplit(tempPhasesNeuronID)=[];
TotalUnitSplitData.TetrodeList(tempPhasesNeuronID)=[];
TotalUnitSplitData.SingleUnitTetrodeList(tempPhasesNeuronID)=[];
TotalUnitSplitData.ShortSPlen(tempPhasesNeuronID)=[];
% TotalUnitSplitData.RuleSequence(tempPhasesNeuronID)=[];
TotalUnitSplitData.AutoCorr(tempPhasesNeuronID)=[];
TotalUnitSplitData.TimeGain(tempPhasesNeuronID)=[];
TotalUnitSplitData.FirstOdor(tempPhasesNeuronID)=[];
TotalUnitSplitData.SecondOdor(tempPhasesNeuronID)=[];
if isfield(TotalUnitSplitData, 'Laser')&&~isempty(TotalUnitSplitData.Laser)
    TotalUnitSplitData.Laser(tempPhasesNeuronID)=[];
end
TotalUnitSplitData.DelayMeanTrialLenMN(tempPhasesNeuronID)=[];
if isfield(TotalUnitSplitData, 'NewLick')&&~isempty(TotalUnitSplitData.NewLick)
    TotalUnitSplitData.NewLick(tempPhasesNeuronID)=[];
end
if isfield(TotalUnitSplitData, 'DistractorTrialInfo')&&~isempty(TotalUnitSplitData.DistractorTrialInfo)
TotalUnitSplitData.DistractorTrialInfo(tempPhasesNeuronID)=[];
TotalUnitSplitData.Distractors(tempPhasesNeuronID)=[];
end