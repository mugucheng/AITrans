function NeuronIDWithReversedOdorSelectivity=IdentifyDelayReversedSelectiveNeuron(DelaySigBinNum...
    ,AllUnitOdorSelectivity,DelayBinID)

SecondBasedTimeLampsedOdorSelectivity=AllUnitOdorSelectivity.NLOdorSelectivityIndex;
MultipleSigBinNeuID=find(DelaySigBinNum>=2);
MultipleSigBinNeuSelectivityIndex=SecondBasedTimeLampsedOdorSelectivity(MultipleSigBinNeuID,DelayBinID);
MultipleSigBinNeuIsSigBin=AllUnitOdorSelectivity.NLIsSignificant(MultipleSigBinNeuID,DelayBinID);

NeuronIDWithReversedOdorSelectivity=[];
for iNeuron=1:length(MultipleSigBinNeuID)
    tempSigSelectivity=MultipleSigBinNeuSelectivityIndex(iNeuron,MultipleSigBinNeuIsSigBin(iNeuron,:)==1);
    if length(find(tempSigSelectivity>0))~=length(tempSigSelectivity)&&length(find(tempSigSelectivity<0))~=length(tempSigSelectivity)
        NeuronIDWithReversedOdorSelectivity=[NeuronIDWithReversedOdorSelectivity;MultipleSigBinNeuID(iNeuron)];
    end
end

