function [NeuronIndexInEachTrainingDay,MiceID]=GetNeuronIndexInEachTrainingDay(DayBasedPerformanceNeuron,MiceID)

NeuronIndexInEachTrainingDay=cell(4,8);
for iDay=1:8%go through each training day
    DayID=['Day' num2str(iDay)];
    T = regexpi(DayBasedPerformanceNeuron(:,1), DayID);
    E = ~cellfun(@isempty, T);
    NeuronIndexInEachTrainingDay{3,iDay}=DayBasedPerformanceNeuron(E,1);    
    tempNeuronID=DayBasedPerformanceNeuron(E,4);    
    NeuronIndexInEachTrainingDay{1,iDay}=vertcat(tempNeuronID{:});
    TargetDayPerformance=DayBasedPerformanceNeuron(E,2);
    NeuronIndexInEachTrainingDay{2,iDay}=vertcat(TargetDayPerformance{:});   
    NeuronIndexInEachTrainingDay{4,iDay}=DayBasedPerformanceNeuron(E,5);   
end
for iMouse=1:length(MiceID)
    T = regexpi(DayBasedPerformanceNeuron(:,1), MiceID{iMouse,1});
    E = ~cellfun(@isempty, T);
    iMouseCrossDayPerformance=DayBasedPerformanceNeuron(E,2);
    MiceID{iMouse,4}=vertcat(iMouseCrossDayPerformance{:});    
    MiceID{iMouse,5}=sum(cell2mat(DayBasedPerformanceNeuron(E,3)));
    NeuronID=DayBasedPerformanceNeuron(E,4);
    MiceID{iMouse,6}=vertcat(NeuronID{:});
end